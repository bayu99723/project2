<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "masukan";

// Buat koneksi
$koneksi = mysqli_connect($host, $user, $password, $database);

// Periksa koneksi
if (!$koneksi) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
